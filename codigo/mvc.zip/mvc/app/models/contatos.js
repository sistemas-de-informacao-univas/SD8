// modelo
module.exports = function() {

	var contatos = []
	return contatos;

};
